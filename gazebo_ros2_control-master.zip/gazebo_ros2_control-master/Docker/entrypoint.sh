#!/bin/sh

. /opt/ros/rolling/setup.sh
. /home/ros2_ws/install/setup.sh
exec "$@"
